/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 /*Thomas Dumont das Neves R.A 22117010-3 09/03/18

  Este programa vem com o objetivo de criar uma classe funcionario em JAVA que contem nome e sobrenome (como string) e salario(como double) e apresentar as informações colocadas com uma funcao imprime, sendo que a primeira parte da impressao é o salario normal e a segunda parte é o salario com um acrescimo de 10%.
  
*/
 

  
*/
package aula.pkg1.java;

class Funcionario {//criando a classe Funcionario

    String nome;//criando as variaveis nome, sobrenome e salario
    String sobrenome;
    double salario;
		
		
		public void setNome(String novoNome) {//metodo para configurar o nome
        nome = novoNome;
    }
    public void setSobrenome(String novoSobrenome) {//metodo para configurar o //sobrenome
        sobrenome = novoSobrenome;
    }

    public void setSalario(double novoSalario) {//metodo para configurar o //salario
        if(novoSalario < 0)//condicao criada para caso o salario seja setado //com um valor abaixo de 0
            salario = 0;
        else
            salario = novoSalario;
    }

   
    
    public String getNome(){//metodo para recuperar o valor do nome
        return nome;
    }
    public String getSobrenome(){//metodo para recuperar o valor do sobrenome
        return sobrenome;
    }
    public double getSalario(){//metodo para recuperar o valor do salario
        return salario;
    }
    public void imprime(){//instrucao que chama os valores de nome, sobrenome e //salario e os apresenta ao usuario
        System.out.println("Nome:   " + getNome());
        System.out.println("Sobrenome:  " + getSobrenome());
        System.out.println("Salario anual:    " + getSalario()*12);
    }
}//fechando classe funcionario

public class Aula1Java {
    public static void imprimeFunc(Funcionario z){
        System.out.println("Nome:   " + z.getNome());
        System.out.println("Sobrenome:  " + z.getSobrenome());
        System.out.println("Salario anual:    " + z.getSalario()*12);
    }
    public static void main(String[] args) {
        
        Funcionario f = new Funcionario();  //criando um objeto e atribuindo //ele a Funcionario
        
        f.setNome("Sergio");
        f.setSobrenome("Carlos");
        f.setSalario(30000.25);
        
        Funcionario g = new Funcionario();//criando um objeto e atribuindo ele //a Funcionario
        
        g.setNome("Albert");
        g.setSobrenome("Mendes");
        g.setSalario(9999999);
        
        f.imprime();
        g.imprime();
        
        f.setSalario(f.getSalario()*1.1);
        g.setSalario(g.getSalario()*1.1);
        f.imprime();//imprimindo o salario com 10% de acrescimo
        g.imprime();
    }

}
