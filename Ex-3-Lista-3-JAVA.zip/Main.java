class Rectangle{
	public Rectangle(float base, float altura){
		if(base > 0 && base < 20 && altura > 0 && altura < 20)
		this.base = base; 
		this.altura=altura;
	}
	public float getArea(){
		float area;
		area = altura * base;
		return area;
	}
	public float getPerim(){
		float perim;
		perim = 2*base + 2*altura;
		return perim;
	}

private float base;
private float altura;
}


class Main {
  public static void main(String[] args) {
   Rectangle BA = new Rectangle(2,6);
    System.out.println("area = " + BA.getArea());
    System.out.println("perimetro = " + BA.getPerim());
  }
}