
/*Thomas Dumont das Neves R.A 22117010-3 09/03/18

  Este programa vem com o objetivo de criar uma classe funcionario em C++ que contem nome, sobrenome (em string ) e salario (em double) privados e apresentar as informações colocadas com uma funcao imprime, sendo que a primeira parte da impressao é o salario normal e a segunda parte é o salario com um acrescimo de 10%.
  
*/
#include <iostream>
#include<string>
#include <cstdlib>

using namespace std;


class Funcionario{//criando classe Funcionario
  private://criando as variaveis nome sobrenome e salario no metodo privado
    string nome;
    string sobrenome;
    double salario;
  public://definindo as funcoes publicas
  void setNome(string novoNome){//metodo para configurar o nome
      nome = novoNome;
    }
    void setSobrenome(string novoSobrenome){//metodo para configurar o sobrenome
      sobrenome = novoSobrenome;
    }
    void setSalario(double novoSalario){//metodo para configurar o salario
      salario = novoSalario;
    }
    
    string getNome(){ // metodo para recuperar o valor do nome
      return nome;
    }
    string getSobrenome(){// metodo para recuperar o valor do sobrenome
      return sobrenome;
    }
    double getSalario(){// metodo para recuperar o valor do salario
      return salario;
    }
  };//fechando classe Funcionario
    void imprime(){//instrucao que chama os valores de nome, sobrenome e //salario e apresenta ao usuario
      cout <<"Nome: " << getNome()<< endl;//metodo de impressao
      cout <<"Sobrenome:  " << getSobrenome()<< endl;
      cout << "Salario anual: " << getSalario()*12 << endl;
    }
};
int main() {//criando main
  Funcionario f1;//definindo f1 como chave de acesso para as funçoes publicas
  f1.setNome("Amaral");//atribuindo valores as variaveis
  f1.setSobrenome("Oliveira");
  f1.setSalario(3000);
  
  
  Funcionario f2;//definindo f2 como chave de acesso para as funçoes publicas
  f2.setNome("Clayton");//atribuindo valores as variaveis
  f2.setSobrenome("Alves");
  f2.setSalario(4000);
  cout << "Funcionario 1" << endl;
  f1.imprime();
  cout << "==============================" << endl;
  cout << "Funcionario 2" << endl;
  f2.imprime();
  cout << "==============================" << endl;
  
  f1.setSalario(f1.getSalario()*1.1);
  f2.setSalario(f2.getSalario()*1.1);
  
  cout << "---------------------" << endl;
  cout << "Salario com os 10%" << endl;
  cout << "---------------------" << endl;
  f1.imprime();
  cout << "==============================" << endl;
  f2.imprime();
  
}//fechando main