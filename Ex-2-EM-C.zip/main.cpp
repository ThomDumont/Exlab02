#include <iostream>
#include<string>
/* Thomas Dumont das Neves R.A 22117010-3 09/03/18

	Este programa em C++ tem como objetivo criar uma classe data com os inteiros dia, mes e ano privados e apresentar-los em uma impressao, sendo que se colocar o dia ou o mes maior que 31 e 12 respectivamente, o programa ira truncar para o  valor mais mais alto possivel, enquanto a variavel ano pode ser inserida qualquer valor.
		

*/

using namespace std;

class Date{ //criando a classe Date
  private: //criando as variaveis dia mes e ano colocando-as em metodo privado
    int dia;
    int mes;
    int ano;
  public://definindo as funcoes publicas
    void setDia(int novoDia){//metodo para configurar o dia 
      if(novoDia < 1)//criando condicao para o dia nao ser maior que 31
        dia = 1;
      else if(novoDia > 31)
        dia = 31;
      else
        dia = novoDia;
    }
    
    void setMes(int novoMes){//metodo para configurar o mes
      if(novoMes < 1)//criando a condicao que faz o mes nao ser maior que 12
        mes = 1;
      else if(novoMes > 12)
        mes = 12;
      else
        mes = novoMes;
    }
    
    void setAno(int novoAno){ //metodo para configurar o ano
      ano = novoAno;
    }
    
    int getDia(){// metodo para recuperar o valor do dia
      return dia;
    }
    int getMes(){// metodo para recuperar o valor do mes
      return mes;
    }
    int getAno(){// metodo para recuperar o valor do ano
      return ano;
    }
    void imprime(){//instrucao que chama os valores do dia do mes e ano  conforme a formatacao solicitada com "/" entre os valores
      cout << getDia() << "/" << getMes() << "/" << getAno();//metodo de //impressao
    }
};//fechando a classe Date

int main() {
  Date d;//definindo d como chave de acesso para as funçoes publicas
  d.setDia(32); //colocando valores em dia
  d.setMes(1);//colocando valores em mes
  d.setAno(1999);//colocando valores em ano
  
  d.imprime();//imprimindo
  
  
}