#include <iostream>
#include <string>
#include "invoice.h"
using namespace std;


int main() {
  invoice d;
  d.setDescric("verde, duravel, impermeavel"); 
  d.setNumide("plastico4312");
  d.setQtcom(1999);
  d.setPrc(3);
  d.imprime();
	}