#include <string>
#include <iostream>
using namespace std;

class invoice{
	private:
		string descric;
		string numide;
		int qtcom;
		int prc;
	
	public:
		invoice();
		void setDescric(string);
		void setNumide(string);
		void setQtcom(int);
		void setPrc(int);
		
		string getDescric();
		string getNumide();
		int getQtcom();
		int getPrc();
		void imprime();
};