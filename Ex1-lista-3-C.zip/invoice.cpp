#include "invoice.h"
using namespace std;

invoice::invoice(){
	descric = "";
	numide = "";
	qtcom = 0;
	prc = 0;
	}

		void invoice :: setDescric(string novoDescric){
			descric = novoDescric; 
		}

		void invoice :: setNumide(string novoNumide){
				numide = novoNumide;
		}
		void invoice :: setQtcom(int novoQtcom){
			if(novoQtcom < 0)
				novoQtcom = 0;
			else
				qtcom = novoQtcom;
		}
		void invoice :: setPrc(int novoPrc){
			if(novoPrc < 0 )
				novoPrc =0;
			else
				prc = novoPrc;	
		}
		
		string invoice :: getDescric(){
			return descric;
		}
		string invoice :: getNumide(){
			return numide;
		}		
		int invoice :: getQtcom(){
			return qtcom;
		}
		int invoice :: getPrc(){
			return prc;
		}
		void invoice :: imprime(){
			cout << "Descricao:"<< getDescric() << endl;
			cout << "Num de id :" << getNumide() << endl; 
			cout	<<"Qt de compra:" <<	getQtcom() << endl; 
			cout << "Preco :" << getPrc() << endl;
  

	
	

		}