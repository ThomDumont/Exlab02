public class Rational {

    public Rational() {
        numerator = 1;
        denominator = 1;
    }

    public Rational(int numerator, int denominator) {
        reduce(numerator,denominator);
    }

    public void reduce(int numerator, int denominator){
        int mdc = MDC(numerator,denominator);
        this.numerator = numerator/mdc;
        this.denominator = denominator/mdc;

    }

    public int getNumerator() {
        return numerator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }

    public int MDC(int a, int b) {
        if (b==0) return a;
        return MDC(b,a%b);
    }

    public void somaRational(Rational a, Rational b){
        int newDenominator = a.getDenominator() * b.getDenominator();
        numerator = (newDenominator/a.getDenominator())*a.getNumerator() + (newDenominator/b.getDenominator())*b.getNumerator();
        denominator = newDenominator;
        reduce(numerator,denominator);
    }

    public void subtraRational(Rational a, Rational b){
        int newDenominator = a.getDenominator() * b.getDenominator();
        numerator = (newDenominator/a.getDenominator())*a.getNumerator() - (newDenominator/b.getDenominator())*b.getNumerator();
        denominator = newDenominator;
        reduce(numerator,denominator);
    }

    public void multipRational(Rational a, Rational b){
        numerator = a.getNumerator()*b.getNumerator();
        denominator = a.getDenominator()*b.getDenominator();
        reduce(numerator,denominator);

    }

    public void divisRational(Rational a, Rational b){
        numerator = a.getNumerator()*b.getDenominator();
        denominator = a.getDenominator()*b.getNumerator();
        reduce(numerator,denominator);
    }

    public String printRational(){
        return String.format("%d/%d",numerator,denominator);
    }

    public String printFlutu(){
        return String.format("%.3f",(float)numerator/denominator);
    }

    private int numerator;
    private int denominator;
}