class Main {
  public static void main(String[] args) {
    Rational frac1 = new Rational(1,2);
        Rational frac2 = new Rational(1,3);
        Rational frac3 = new Rational();
                
        System.out.println("===========================================");
        System.out.print("primeira fracao: ");
        System.out.println(frac1.printRational());
        System.out.print("segunda fracao: ");
        System.out.println(frac2.printRational());


        System.out.println("===========================================");
        System.out.print("A soma das fracoes eh = ");
        frac3.somaRational(frac1, frac2);
        System.out.println(frac3.printRational());
        System.out.println("O resultado em ponto flutuante:  ");
        System.out.println(frac3.printFlutu());
        
        
        System.out.println("===========================================");
        System.out.print("A subtracao das fracoes eh= ");
        frac3.subtraRational(frac1,frac2);
        System.out.println(frac3.printRational());
        System.out.println("O resultado em ponto flutuante:  ");
        System.out.println(frac3.printFlutu());
        
        
        System.out.println("===========================================");
        System.out.print("Multiplicacao das fracoes eh=  ");
        frac3.multipRational(frac1,frac2);
        System.out.println(frac3.printRational());
        System.out.println("O resultado em ponto flutuante: ");
        System.out.println(frac3.printFlutu());
        
        
        System.out.println("===========================================");
        System.out.print("Divisao das fracoes eh= ");
        frac3.divisRational(frac1,frac2);
      	System.out.println(frac3.printRational());
      	System.out.println("O resultado em ponto flutuante: ");
        System.out.println(frac3.printFlutu());

  }
}