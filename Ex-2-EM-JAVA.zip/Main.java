/* Thomas Dumont das Neves R.A 22117010-3 09/03/18

	Este programa em JAVA tem como objetivo criar uma classe data com os inteiros dia, mes e ano e apresentar-los em uma impressao, sendo que se colocar o dia ou o mes maior que 31 e 12 respectivamente, o programa ira truncar para o  valor mais mais alto possivel, enquanto a variavel ano segue sem restricoes.
		

*/





package exercicio.pkg2.aula.pkg2;

class Date {//criando a classe Date
    int mes;//criando as variaveis mes, dia e ano
    int dia;
    int ano;
    
    public void setDia(int novoDia) {//metodo para configurar o dia 
      if (dia < 1) //criando a condicao que faz o dia nao ser maior que 31
				dia = 1;
      else if (dia > 31)
				dia = 31;
      else
				dia = novoDia;
    }
    
    public void setMes(int novoMes) {// metodo para configurar o mes
        if(mes < 1)//criando a condicao que faz o mes nao ser maior que 12
            mes = 1;
        else if (mes > 12)
            mes = 12;
        else
            mes = novoMes;
    }
   
    public void setAno(int novoAno){//metodo para configurar o ano
        ano = novoAno;
    }
    
    
    
    public int getDia(){// metodo para recuperar o valor do dia
        return dia;
    }
    public int getMes(){// metodo para recuperar o valor do mes
        return mes;
    }
   
    public int getAno(){// metodo para recuperar o valor do ano
        return ano;
    }
    public void imprime(){//instrucao que chama os valores do dia do mes e ano  //conforme a formatacao solicitada com "/" entre os valores
        System.out.println(getDia() + "/" getMes() + "/" getAno());
        
    }    
        
    }
   
    
}//fechado a classe Date
public class Exercicio2Aula2 {

    
    public static void main(String[] args) {//metodo main que inicializa o //programa
        Date d = new Date(); //criando um objeto e atribuindo ele a Date
        
        d.setDia(12);//inserindo os valores de dia mes e ano
        d.setMes(5);
        d.setAno(2018);
        
        d.imprime();//imprimindo a data inserida 
    }//fechando main
    
}//fim da classe Exercicio2Aula2