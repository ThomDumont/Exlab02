#include "Complex.h"

using namespace std;

int main() {
    Complex a(5,-3);
    Complex b(-5,3);
    Complex c;


    c.subtComplex(a,b);
    c.printComplex();
    c.somaComplex(a,b);
    c.printComplex();

    return 0;
}