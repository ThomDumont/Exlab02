#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

class Complex{
public:
    Complex();
    Complex(double,double);
    double getNreal();
    double getNimag();
    void setNreal(double);
    void setNimag(double);
    void somaComplex(Complex,Complex);
    void subtComplex(Complex,Complex);
    void printComplex();

private:
    double nreal;
    double nimag;
};

