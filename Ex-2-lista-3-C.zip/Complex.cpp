#include "Complex.h"

Complex::Complex() {
    nreal = 1;
    nimag = 1;
}

Complex::Complex(double a, double b) {
    nreal = a;
    nimag = b;
}

double Complex::getNreal(){
    return nreal;
}

double Complex::getNimag(){
    return nimag;
}

void Complex::setNreal(double nreal){
    this->nreal = nreal;
}

void Complex::setNimag(double nimag){
    this->nimag = nimag;
}

void Complex::somaComplex(Complex a, Complex b) {
    nreal = a.nreal + b.nreal;
    nimag = a.nimag + b.nimag;
    cout << "(" << a.getNreal() <<", " << a.getNimag() <<"i) + (" << b.getNreal() <<", " << b.getNimag() <<"i) = ";
}

void Complex::subtComplex(Complex a,Complex b){
    nreal = a.nreal + (b.nreal * -1);
    nimag = a.nimag + (b.nimag * -1);
    cout << "(" << a.getNreal() <<", " << a.getNimag() <<"i) - (" << b.getNreal() <<", " << b.getNimag() <<"i) = ";
}

void Complex::printComplex() {
    if (nimag == 0)
        cout << "(" << getNreal() <<", 0)\n";
    else
        cout << "(" << getNreal() <<", " << getNimag() <<"i)\n";
}