class Main {
  public static void main(String[] args) {
    Time2 hora = new Time2(20,06,59);
        System.out.println(hora.toUniversalString());
        hora.tick();
        System.out.println(hora.toUniversalString());
        System.out.println("---------------");
        hora.setTime(14,59,59);
        System.out.println(hora.toUniversalString());
        hora.tick();
        System.out.println(hora.toUniversalString());
        System.out.println("---------------");
        hora.setTime(23,59,59);
        System.out.println(hora.toUniversalString());
        hora.tick();
        System.out.println(hora.toUniversalString());

  }
}